#include "header.h"

//#include <fenv.h>

int main(int argc, char* argv[]) 
{
    //feenableexcept(FE_DIVBYZERO | FE_INVALID | FE_OVERFLOW | FE_UNDERFLOW);
    if (argc < 6) {
        printf("Usage: %s n m p r s [filename]\n", argv[0]);
        return 1;
    }

    int n = std::atoi(argv[1]); 
    int m = std::atoi(argv[2]);
    int p = std::atoi(argv[3]);
    int r = std::atoi(argv[4]); 
    int s = std::atoi(argv[5]); 

    int sol_status;

    double r1, r2, norm;

    double t1, t2;

    double* A = new double[n * n];
    double* B = new double[n];
    double* X = new double[n]; 

    Args* args = new Args[p];

    pthread_barrier_t barrier;

    if (s == 0 && argc == 7) 
    {
        const char* filename = argv[6];
        if(ReadFromFile(filename, A, n) != 0)
        {
            delete[] A;
            delete[] B;
            delete[] X;
            delete[] args;
            return 1;
        }
    }
    else
        InitializeMatrix(A, s, n);

    printf("Matrix A:\n");

    PrintMatrix(A, r, n, n);

    norm = A[0];

    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
            if(std::abs(A[i * n + j]) < norm)
                norm = std::abs(A[i * n + j]);
    }

    //printf("norm = %e\n", norm);

    CalcB(A, B, n);

    pthread_barrier_init(&barrier, 0, p);

    for(int i = 0; i < p; i++)
    {
        if(args[i].init(n, m, r, s, argv[6], i, p, norm, A, B, X, &barrier) != 0)
        {
            printf("Not enough memory for thread %d data\n", i);
            delete[] A;
            delete[] B;
            delete[] X;
            delete[] args;
            return 2;
        }
    }

    for(int i = 1; i < p; i++)
    {
        if(pthread_create(&args[i].tid, nullptr, thread_func, args + i))
        {
            printf("Can not create thread %d\n", i);
            delete[] A;
            delete[] B;
            delete[] X;
            delete[] args;
            return 3;
        }
    }

    args[0].tid = pthread_self();
    thread_func(args + 0);
    
    for(int i = 1; i < p; i++)
        pthread_join(args[i].tid, nullptr);

    //PrintMatrix(A, n, n, n);


    sol_status = args[0].sol_status;
    t1 = args[0].sol_full_time;
    t2 = args[0].d_full_time;
    r1 = args[0].r1;
    r2 = args[0].r2;

    if (sol_status != 0) 
    {
        printf("Error: Unable to solve the system\n");
        delete[] A;
        delete[] B;
        delete[] X;
        delete[] args;

        printf("%s : Task = %d Res1 = %d Res2 = %d T1 = %.2f T2 = %d S = %d N = %d M = %d P = %d\n", argv[0], 21, -1, -1, t1, 0, s, n, m, p);

        return 1;
    }

    //for(int i = 0; i < p; i++)
      //  args[i].print();

    double s1 = 0;
    double s2 = 0;

    for(int i = 0; i < p; i++)
    {
        s1 += args[i].sol_cpu_time * args[i].sol_cpu_time;
        s2 += args[i].sol_cpu_time;
    }

    printf("cpu_time variance = %lf\n", s1/p - s2*s2/(p*p));

    s1 = s2 = 0;

    for(int i = 0; i < p; i++)
    {
        s1 += args[i].sol_full_time * args[i].sol_full_time;
        s2 += args[i].sol_full_time;
    }
    printf("full_time variance = %lf\n", s1/p - s2*s2/(p*p));

    //printf("t1 = %lf\nt2 = %lf\nt3 = %lf\n", args[0].t1, args[0].t2, args[0].t3);

    printf("%s : Task = %d Res1 = %e Res2 = %e T1 = %.2f T2 = %.2f S = %d N = %d M = %d P = %d\n", argv[0], 21, r1, r2, t1, t2, s, n, m, p);
    
    delete[] A;
    delete[] B;
    delete[] X;
    delete[] args;
    pthread_barrier_destroy(&barrier);

    return 0;
}
